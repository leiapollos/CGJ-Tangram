#pragma once

#define PI 3.14159265f
#define EPSILON 0.0001f
#define CLEAN_TOLERANCE 4

#define CAMERA_SPEED 0.1f
#define CAMERA_SENSITIVITY 0.05f;